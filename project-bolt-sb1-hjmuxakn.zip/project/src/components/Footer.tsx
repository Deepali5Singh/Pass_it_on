import { Github, Instagram, Linkedin, Mail, MessageCircle } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">About Us</h3>
            <p className="text-gray-300">
              At Pass It On, we're committed to creating a sustainable future by connecting people who want to share resources locally. Our platform helps reduce waste and build stronger communities through the power of sharing.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/about" className="text-gray-300 hover:text-white">About Us</a></li>
              <li><a href="/listings" className="text-gray-300 hover:text-white">Browse Listings</a></li>
              <li><a href="/contact" className="text-gray-300 hover:text-white">Contact Us</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Connect With Us</h3>
            <div className="flex flex-col space-y-2">
              <a
                href="https://linkedin.com/in/aman-singh-459521164"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-300 hover:text-white"
              >
                <Linkedin className="h-5 w-5 mr-2" />
                <span>LinkedIn</span>
              </a>
              <a
                href="https://github.com/aman113114singh"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-300 hover:text-white"
              >
                <Github className="h-5 w-5 mr-2" />
                <span>GitHub</span>
              </a>
              <a
                href="https://www.instagram.com/aman113114singh"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-300 hover:text-white"
              >
                <Instagram className="h-5 w-5 mr-2" />
                <span>Instagram</span>
              </a>
              <a
                href="https://wa.me/917388797882"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center text-gray-300 hover:text-white"
              >
                <MessageCircle className="h-5 w-5 mr-2" />
                <span>WhatsApp</span>
              </a>
              <a
                href="mailto:amancdspace@gmail.com"
                className="flex items-center text-gray-300 hover:text-white"
              >
                <Mail className="h-5 w-5 mr-2" />
                <span>Email</span>
              </a>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Pass It On. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}