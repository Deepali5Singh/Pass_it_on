export interface User {
  id: string;
  email: string;
  name: string;
  age: number;
  gender: string;
  location: string;
  profession: string;
  created_at: string;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  category: string[];
  manufacturing_date?: string;
  expiry_date?: string;
  location: string;
  images: string[];
  user_id: string;
  created_at: string;
  status: 'available' | 'given';
}