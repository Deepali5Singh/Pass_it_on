import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import type { Listing } from '../lib/types';
import toast from 'react-hot-toast';

export function MyListings() {
  const { user } = useAuth();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchMyListings();
    }
  }, [user]);

  async function fetchMyListings() {
    try {
      const { data, error } = await supabase
        .from('listings')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setListings(data || []);
    } catch (error) {
      toast.error('Error fetching your listings');
    } finally {
      setLoading(false);
    }
  }

  async function updateListingStatus(listingId: string, status: 'available' | 'given') {
    try {
      const { error } = await supabase
        .from('listings')
        .update({ status })
        .eq('id', listingId)
        .eq('user_id', user?.id);

      if (error) throw error;

      toast.success('Listing status updated successfully');
      fetchMyListings();
    } catch (error) {
      toast.error('Error updating listing status');
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="text-gray-500">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">My Listings</h1>

      {listings.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">You haven't created any listings yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {listings.map((listing) => (
            <div
              key={listing.id}
              className="bg-white overflow-hidden shadow rounded-lg"
            >
              {listing.images.length > 0 && (
                <img
                  src={listing.images[0]}
                  alt={listing.title}
                  className="w-full h-48 object-cover"
                />
              )}
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-medium text-gray-900">{listing.title}</h3>
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      listing.status === 'available'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {listing.status === 'available' ? 'Available' : 'Given'}
                  </span>
                </div>
                <p className="text-sm text-gray-500">{listing.description}</p>
                <div className="mt-2 flex flex-wrap gap-1">
                  {listing.category.map((cat) => (
                    <span
                      key={cat}
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800"
                    >
                      {cat}
                    </span>
                  ))}
                </div>
                <p className="mt-2 text-sm text-gray-500">
                  Location: {listing.location}
                </p>
                {listing.manufacturing_date && (
                  <p className="mt-1 text-sm text-gray-500">
                    Manufacturing Date: {new Date(listing.manufacturing_date).toLocaleDateString()}
                  </p>
                )}
                {listing.expiry_date && (
                  <p className="mt-1 text-sm text-gray-500">
                    Expiry Date: {new Date(listing.expiry_date).toLocaleDateString()}
                  </p>
                )}
                <div className="mt-4">
                  <button
                    onClick={() =>
                      updateListingStatus(
                        listing.id,
                        listing.status === 'available' ? 'given' : 'available'
                      )
                    }
                    className={`w-full px-4 py-2 border border-transparent text-sm font-medium rounded-md ${
                      listing.status === 'available'
                        ? 'text-white bg-green-600 hover:bg-green-700'
                        : 'text-green-700 bg-green-100 hover:bg-green-200'
                    }`}
                  >
                    {listing.status === 'available'
                      ? 'Mark as Given'
                      : 'Mark as Available'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}