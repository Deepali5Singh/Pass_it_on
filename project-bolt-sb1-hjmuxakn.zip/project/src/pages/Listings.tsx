import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Listing } from '../lib/types';
import toast from 'react-hot-toast';

export function Listings() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [searchLocation, setSearchLocation] = useState('');

  const categories = [
    'Food Items',
    'Furniture',
    'Vehicles',
    'Pets',
    'Consumables',
    'Others',
  ];

  useEffect(() => {
    fetchListings();
  }, []);

  async function fetchListings() {
    try {
      let query = supabase
        .from('listings')
        .select('*')
        .eq('status', 'available')
        .order('created_at', { ascending: false });

      if (selectedCategories.length > 0) {
        query = query.contains('category', selectedCategories);
      }

      if (searchLocation) {
        query = query.ilike('location', `%${searchLocation}%`);
      }

      const { data, error } = await query;

      if (error) throw error;
      setListings(data || []);
    } catch (error) {
      toast.error('Error fetching listings');
    } finally {
      setLoading(false);
    }
  }

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category]
    );
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4 sm:mb-0">Available Items</h1>
        <Link
          to="/listings/new"
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          Create Listing
        </Link>
      </div>

      <div className="mb-8">
        <div className="mb-4">
          <label htmlFor="location" className="block text-sm font-medium text-gray-700">
            Search by location
          </label>
          <input
            type="text"
            id="location"
            value={searchLocation}
            onChange={(e) => setSearchLocation(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 sm:text-sm"
            placeholder="Enter location..."
          />
        </div>

        <div>
          <h2 className="text-sm font-medium text-gray-700 mb-2">Categories</h2>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => toggleCategory(category)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  selectedCategories.includes(category)
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={fetchListings}
          className="mt-4 px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
        >
          Apply Filters
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {listings.map((listing) => (
          <div
            key={listing.id}
            className="bg-white overflow-hidden shadow rounded-lg"
          >
            {listing.images.length > 0 && (
              <img
                src={listing.images[0]}
                alt={listing.title}
                className="w-full h-48 object-cover"
              />
            )}
            <div className="p-4">
              <h3 className="text-lg font-medium text-gray-900">{listing.title}</h3>
              <p className="mt-1 text-sm text-gray-500">{listing.description}</p>
              <div className="mt-2 flex flex-wrap gap-1">
                {listing.category.map((cat) => (
                  <span
                    key={cat}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800"
                  >
                    {cat}
                  </span>
                ))}
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Location: {listing.location}
              </p>
              {listing.manufacturing_date && (
                <p className="mt-1 text-sm text-gray-500">
                  Manufacturing Date: {new Date(listing.manufacturing_date).toLocaleDateString()}
                </p>
              )}
              {listing.expiry_date && (
                <p className="mt-1 text-sm text-gray-500">
                  Expiry Date: {new Date(listing.expiry_date).toLocaleDateString()}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>

      {listings.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No listings found.</p>
        </div>
      )}
    </div>
  );
}